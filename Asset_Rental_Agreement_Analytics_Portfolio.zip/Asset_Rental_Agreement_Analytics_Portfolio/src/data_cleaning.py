"""Utility functions for the Asset Rental Agreement Analytics project."""

import pandas as pd


def clean_column_names(df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy of the DataFrame with clean snake_case column names."""
    clean_df = df.copy()
    clean_df.columns = (
        clean_df.columns
        .str.strip()
        .str.lower()
        .str.replace(" ", "_", regex=False)
        .str.replace(".", "", regex=False)
    )
    return clean_df


def add_lease_features(df: pd.DataFrame) -> pd.DataFrame:
    """Create lease analytics features used for EDA and modeling."""
    data = df.copy()
    for col in ["commencement_date", "primary_term_date"]:
        if col in data.columns:
            data[col] = pd.to_datetime(data[col], errors="coerce")

    if {"asset_rental_amount", "asset_cost"}.issubset(data.columns):
        data["rental_to_cost_ratio"] = data["asset_rental_amount"] / data["asset_cost"]

    if "commencement_date" in data.columns:
        data["commencement_year"] = data["commencement_date"].dt.year
        data["lease_age_days"] = (pd.Timestamp.today().normalize() - data["commencement_date"]).dt.days

    if "primary_term_date" in data.columns:
        data["days_until_primary_term_end"] = (data["primary_term_date"] - pd.Timestamp.today().normalize()).dt.days

    return data
